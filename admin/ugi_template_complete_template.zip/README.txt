UGI Asset Template
==================================================

FILE STRUCTURE
--------------
1. ugi_template_data.csv - Main data file with 20 sample rows
2. Multiple lookup CSV files - Reference tables with valid ID values

FIELD DESCRIPTIONS
------------------
name                      : UGI asset name (REQUIRED)
                            Example: Friendship Park

amharic_name              : Name in Amharic (optional)
                            Example: የጓደኝነት ፓርክ

ugi_type_id               : UGI type ID (see UGI Types sheet) (REQUIRED)
                            Example: 1
                            See ugi_types.csv for valid values

parcel_id                 : Parcel UUID (see Sample Parcels sheet) (REQUIRED)
                            Example: 1

condition_status_id       : Condition status ID (see Conditions sheet) (optional)
                            Example: 2
                            See conditions.csv for valid values

operational_status_id     : Operational status ID (see Operational Status sheet) (optional)
                            Example: 1
                            See operational.csv for valid values

has_lighting              : Has lighting (true/false) (optional)
                            Example: true

has_irrigation            : Has irrigation (true/false) (optional)
                            Example: false

has_fencing               : Has fencing (true/false) (optional)
                            Example: true

accessibility_type_id     : Accessibility type ID (see Accessibility sheet) (optional)
                            Example: 1
                            See accessibility.csv for valid values

visitor_capacity          : Estimated visitor capacity (optional)
                            Example: 500

contact_person            : Contact person name (optional)
                            Example: Abebe Kebede

contact_phone             : Contact phone number (optional)
                            Example: +251-911-123-456

contact_email             : Contact email (optional)
                            Example: park.manager@example.com

tree_count                : Number of trees (optional)
                            Example: 120

area_sq_m                 : Area in square meters (optional)
                            Example: 25000.00

establishment_date        : Establishment date (optional)
                            Example: 2010-05-20

last_inspected_date       : Last inspection date (optional)
                            Example: 2024-02-15


IMPORTANT NOTES
---------------
1. Coordinate System: EPSG:20137 (UTM zone 37S for Ethiopia)
2. Geometry Type: Polygon/MultiPolygon
3. Use the sample rows as a guide for data format
4. All ID fields must reference existing values in lookup tables
5. Boolean fields accept: true/false, 1/0, yes/no
6. Date format: YYYY-MM-DD
7. UUID format: 123e4567-e89b-12d3-a456-426614174000

INSTRUCTIONS
------------
1. Review the lookup CSV files to understand valid ID values
2. Use the sample rows as templates for your data
3. Create your shapefile with the same field names
4. Ensure geometry is in EPSG:20137
5. Save all shapefile components (.shp, .shx, .dbf, .prj)
6. ZIP all files and upload through the import interface

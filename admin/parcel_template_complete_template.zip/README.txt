Land Parcel Template
==================================================

FILE STRUCTURE
--------------
1. parcel_template_data.csv - Main data file with 20 sample rows
2. Multiple lookup CSV files - Reference tables with valid ID values

FIELD DESCRIPTIONS
------------------
parcel_number             : Unique parcel identifier (REQUIRED)
                            Example: PARC-2024-001

parcel_registration_number : Official registration number (optional)
                            Example: REG/2024/12345

land_use_type_id          : Land use type ID (see Land Use Types sheet) (optional)
                            Example: 7
                            See land_use.csv for valid values

ownership_type_id         : Ownership type ID (see Ownership Types sheet) (optional)
                            Example: 3
                            See ownership.csv for valid values

owner_name                : Name of owner (optional)
                            Example: Addis Ababa City Administration

owner_id_number           : Owner ID number (optional)
                            Example: ID-12345-AA

owner_contact             : Owner contact information (optional)
                            Example: +251-11-123-4567

region_id                 : Region ID (see Regions sheet) (optional)
                            Example: 1
                            See regions.csv for valid values

city_id                   : City ID (see Cities sheet) (optional)
                            Example: 1
                            See cities.csv for valid values

subcity_id                : Sub-city ID (see Sub-cities sheet) (optional)
                            Example: 101
                            See subcities.csv for valid values

woreda_id                 : Woreda ID (see Woredas sheet) (optional)
                            Example: 1001
                            See woredas.csv for valid values

kebele_id                 : Kebele ID (see Kebeles sheet) (optional)
                            Example: 10001
                            See kebeles.csv for valid values

street_name               : Street name (optional)
                            Example: Bole Road

house_number              : House number (optional)
                            Example: 123

landmark                  : Nearby landmark (optional)
                            Example: Near Mexico Square

registration_date         : Registration date (YYYY-MM-DD) (optional)
                            Example: 2024-01-15

area_sq_m                 : Area in square meters (optional)
                            Example: 1250.50

spatial_accuracy          : Spatial accuracy (High, Medium, Low) (optional)
                            Example: High

survey_date               : Survey date (optional)
                            Example: 2023-12-10

survey_method             : Survey method (GPS, Digitized, Total Station) (optional)
                            Example: GPS


IMPORTANT NOTES
---------------
1. Coordinate System: EPSG:20137 (UTM zone 37S for Ethiopia)
2. Geometry Type: Polygon/MultiPolygon
3. Use the sample rows as a guide for data format
4. All ID fields must reference existing values in lookup tables
5. Boolean fields accept: true/false, 1/0, yes/no
6. Date format: YYYY-MM-DD
7. UUID format: 123e4567-e89b-12d3-a456-426614174000

INSTRUCTIONS
------------
1. Review the lookup CSV files to understand valid ID values
2. Use the sample rows as templates for your data
3. Create your shapefile with the same field names
4. Ensure geometry is in EPSG:20137
5. Save all shapefile components (.shp, .shx, .dbf, .prj)
6. ZIP all files and upload through the import interface

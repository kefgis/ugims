UGIMS Shapefile Template - PARCEL
================================

Field Descriptions:
  PARCEL_NO       : Unique parcel identifier (required)
  REG_NO          : Official registration number
  LAND_USE        : Land use type ID (see lookup table)
  OWNERSHIP       : Ownership type ID (see lookup table)
  OWNER_NAME      : Name of owner
  OWNER_ID        : Owner ID number
  OWNER_CONT      : Owner contact info
  REGION_ID       : Region ID
  CITY_ID         : City ID
  WARD_ID         : Ward ID
  STREET          : Street name
  HOUSE_NO        : House number
  LANDMARK        : Nearby landmark
  REG_DATE        : Registration date (YYYY-MM-DD)
  ACCURACY        : Spatial accuracy (e.g., High, Medium)
  SURV_DATE       : Survey date
  SURV_METH       : Survey method (GPS, Digitized, etc.)


Coordinate System: EPSG:32737 (UTM zone 37S)
Geometry Type: Polygon

Instructions:
1. Create a shapefile with the fields listed above
2. Use the CSV file as a guide for field names and data types
3. Draw polygons in UTM zone 37S coordinates
4. Save and ZIP all shapefile components (.shp, .shx, .dbf, .prj)
5. Upload the ZIP file through the import interface

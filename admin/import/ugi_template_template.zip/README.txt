UGIMS Shapefile Template - UGI
================================

Field Descriptions:
  UGI_NAME        : Name of the green infrastructure asset (required)
  AMH_NAME        : Name in Amharic
  UGI_TYPE        : UGI type ID (see lookup table)
  PARCEL_ID       : UUID of containing parcel (required)
  CONDITION       : Condition status ID
  OPER_STAT       : Operational status ID
  LIGHTING        : Has lighting (true/false)
  IRRIGAT         : Has irrigation (true/false)
  FENCING         : Has fencing (true/false)
  VISIT_CAP       : Visitor capacity
  CONTACT_P       : Contact person name
  CONTACT_PH      : Contact phone
  CONTACT_EM      : Contact email
  TREE_CNT        : Number of trees


Coordinate System: EPSG:32737 (UTM zone 37S)
Geometry Type: Polygon

Instructions:
1. Create a shapefile with the fields listed above
2. Use the CSV file as a guide for field names and data types
3. Draw polygons in UTM zone 37S coordinates
4. Save and ZIP all shapefile components (.shp, .shx, .dbf, .prj)
5. Upload the ZIP file through the import interface
